UHHHHH HELOOOOOOOO
https://puu.sh/KdBdj/084a603b62.png
This is my tf2 config!!! enjoy
https://docs.comfig.app/latest/setup/clean_up/
É^?this above is for resetting your tf2 settings to default before you come here or whatever
-novid -nojoy -nosteamcontroller -nohltv -particles 1 -precachefontchars
^launch options
in game sens varries 800 dpi
